member(E,[E|_]).
member(E,[_|T]):-member(E,T).
node(X,[[X,C]|T]):-!.
node(X,[_|T]):-node1(X,T).
edge(X, Y, [V,E]) :- member([X,Y], E).
getColourNode(Node,[[],E],-1).
getColourNode(Node, [[[Node,C]|T],E],C):-!.
getColourNode(Node,[[_|T],E],R):-getColourNode(Node,[T,E],R).
edge_out1(Node,[],[]).
edge_out1(Node,[[Node,X]|T],[X|R1]):- edge_out1(Node,T,R1),!.
edge_out1(Node,[[_,_]|T],R):- edge_out1(Node,T,R).
edge_out(Node,[V,E],R):-edge_out1(Node,E,R).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat care primeste 2 liste A,B si returneaza A\B.

diferenta_multimi([],B,[]).
diferenta_multimi([X|A],B,[X|R]):-not(member(X,B)),diferenta_multimi(A,B,R),!.
diferenta_multimi([X|A],B,R):-member(X,B),diferenta_multimi(A,B,R),!.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat care concateneaza 2 liste primite ca parametri,fara duplicate.

merge_lists([],L2,L2).	
merge_lists([X|L1],L2,[X|R1]):- not(member(X,L2)),merge_lists(L1,L2,R1).
merge_lists([X|L1],L2,R):- member(X,L2),merge_lists(L1,L2,R).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	predicat care primeste un nod Destinatie,un graf,un Node si o formula F si aplica formula F pe Node,returnand formula Formula_noua
%	Am avut nevoie si de Destination pentru ca schimba_formula se va comporta diferit daca Node == Destination.De exemplu,daca am formula 
%	future(rosu),iar Node=Destination,ar trebui sa returnez true sau false in functie de culoare pe care o are Destination.Totusi,daca 
%	Node \= Destination,iar Node are culoare diferita de rosu,formula noua va fi tot future(rosu).Aceste cazuri se aplica si la celelalte 
%	cazuri.A se observa modul cum o formula este redusa,daca se poate (acest lucru e vizibil la cazurile and,or,next)
	
schimba_formula(D,G,Node,valid,true):-!.
schimba_formula(D,G,Node,true,true):-!.
schimba_formula(D,G,Node,false,false):-!.
schimba_formula(D,G,D,F,true):-future(C)=F,getColourNode(D,G,R),R==C,!.
schimba_formula(D,G,D,F,false):-future(C)=F,getColourNode(D,G,R),R\=C,!.
schimba_formula(D,G,Node,F,true):-future(C)=F,getColourNode(Node,G,R),R==C,!.
schimba_formula(D,G,Node,F,F):-future(C)=F,getColourNode(Node,G,R),R\=C,!.
schimba_formula(D,G,D,F,true):-global(C)=F,getColourNode(D,G,R),R==C,!.
schimba_formula(D,G,D,F,false):-global(C)=F,getColourNode(D,G,R),R\=C,!.
schimba_formula(D,G,Node,F,F):-global(C)=F,getColourNode(Node,G,R),R==C,!.
schimba_formula(D,G,Node,F,false):-global(C)=F,getColourNode(Node,G,R),R\=C,!.
schimba_formula(D,G,D,F,true):-until(C1,C2)=F,getColourNode(D,G,R),R==C1,!.
schimba_formula(D,G,D,F,true):-until(C1,C2)=F,getColourNode(D,G,R),R==C2,!.
schimba_formula(D,G,D,F,false):-until(C1,C2)=F,!.
schimba_formula(D,G,Node,F,F):-until(C1,C2)=F,getColourNode(Node,G,R),R==C1,!.
schimba_formula(D,G,Node,F,true):-until(C1,C2)=F,getColourNode(Node,G,R),R==C2,!.
schimba_formula(D,G,Node,F,false):-until(C1,C2)=F,getColourNode(Node,G,R),R\=C1,R\=C2,!.
schimba_formula(D,G,D,F,false):-next(F1)=F,!.
schimba_formula(D,G,Node,F,F1):-next(F1)=F,!.
schimba_formula(D,G,Node,F,true):- and(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R1==true,R2==true,!.
schimba_formula(D,G,Node,F,false):- and(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R1 == false,!.
schimba_formula(D,G,Node,F,false):- and(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R2 == false,!.
schimba_formula(D,G,Node,F,R2):- and(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R1 == true,!.
schimba_formula(D,G,Node,F,R1):- and(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R2 == true,!.
schimba_formula(D,G,Node,F,and(R1,R2)):- and(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),!.
schimba_formula(D,G,Node,F,true):-or(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R1==true,!.
schimba_formula(D,G,Node,F,true):-or(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R2==true,!.
schimba_formula(D,G,Node,F,R2):-or(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R1==false,!.
schimba_formula(D,G,Node,F,R1):-or(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),R2==false,!.
schimba_formula(D,G,Node,F,or(R1,R2)):-or(F1,F2)=F,schimba_formula(D,G,Node,F1,R1),schimba_formula(D,G,Node,F2,R2),!.
schimba_formula(D,G,Node,F,false):-not(F1)=F,schimba_formula(D,G,Node,F1,R1),R1==true,!.
schimba_formula(D,G,Node,F,true):-not(F1)=F,schimba_formula(D,G,Node,F1,R1),R1==false,!.
schimba_formula(D,G,Node,F,not(R1)):-not(F1)=F,schimba_formula(D,G,Node,F1,R1),!.
schimba_formula(D,G,Node,F,true):- getColourNode(Node,G,R),R==F,!.
schimba_formula(D,G,Node,F,false):- getColourNode(Node,G,R),R\=F,!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat care primeste un nod Destinatie,un nod initial Node,o formula,si un Graf si o lista de vecini pentru Node
%	si construieste o lista de perechi de forma [Vecin,Formula_noua],unde Formula_noua se obtine aplicand formula F pe Vecin.

propaga_regula_vecini(D,N,F,G,[],[]):-!.

%	Aceste 2 reguli de mai jos trateaza cazul cand Vecin = Destinatie (pentru ca daca nu avem true ,nu are sens sa bagam in lista de perechi
%	si perechea [Destinatie,Formula],deoarece ar insemna ca deja am vizitat nodul Destinatie,si nu am satisacut conditia,deci pentru a ajunge
%	din nou aici ar insemna sa trecem prin Destinatie de 2 ori,fapt nepermis conform enuntului).

propaga_regula_vecini(D,N,F,G,[D|L_vecini],[[D,F1]|R]):-schimba_formula(D,G,D,F,F1),F1 == true, propaga_regula_vecini(D,N,F,G,L_vecini,R),!.
propaga_regula_vecini(D,N,F,G,[D|L_vecini],R):-schimba_formula(D,G,D,F,F1),F1 \= true, propaga_regula_vecini(D,N,F,G,L_vecini,R),!.

%	Cazul cand nu Vecin \= Destinatie.Daca formula e false nu adaugam perechea,altfel adaugam(poate fi true sau o alta formula de satisfacut).

propaga_regula_vecini(D,N,F,G,[V|L_vecini],R):-schimba_formula(D,G,V,F,F1),F1 == false, propaga_regula_vecini(D,N,F,G,L_vecini,R),!.
propaga_regula_vecini(D,N,F,G,[V|L_vecini],[[V,F1]|R]):-schimba_formula(D,G,V,F,F1),F1 \= false, propaga_regula_vecini(D,N,F,G,L_vecini,R),!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat care primeste un nod destinatie,un Path = [Lista,Formula],si un graf si genereaza o lista de perechi de forma [Vecin,F],folosindu-se
%	de predicatele edge_out si propaga_regula_vecini pentru a alege nodurile care nu se repeta in Lista si care au muchie cu primul nod din Lista.

create_neighbours(D,Path,G,R1):- [[N|T],F]=Path,edge_out(N,G,E),diferenta_multimi(E,[N|T],E_final),propaga_regula_vecini(D,N,F,G,E_final,R1).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat care primeste un Path=[List_initiala,Formula_veche] si o lista de perechi de forma [Vecin,Formula_noua] si are rolul de a crea o lista 
%	[Lista_noua,F_new] ,unde la Lista_noua = [Vecin|List_initiala],iar F_new = Formula_noua 

add_path(Path,[],[]):-!.
add_path(Path,[V|List],[New_Path|R]):-[N,F]=V,[L,F_old]=Path,New_Path = [[N|L],F],add_path(Path,List,R),!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat care primeste un nod Destinatie,o lista de pathuri (perechi de forma [Lista,Formula]), si un graf, iar pentru fiecare astfel de pereche 
%	genereaza toate perechile [Lista_noua,Formula_noua] prin adaugarea tuturor vecinilor primului element din Lista si schimbarea Formula->Formula_noua
%	Daca o pereche e vida,nu o mai adaugam in lista de drumuri.(complexitate mai buna la parcurgerea ulterioara a listei).

adauga_vecini_la_pathuri(D,[],G,[]):-!.
adauga_vecini_la_pathuri(D,[Path|Paths],G,R):- Path == [],adauga_vecini_la_pathuri(D,Paths,G,R),!.
adauga_vecini_la_pathuri(D,[Path|Paths],G,R_final):- Path \= [],create_neighbours(D,Path,G,R1),add_path(Path,R1,R2),
																adauga_vecini_la_pathuri(D,Paths,G,R),append(R2,R,R_final),!.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat care primeste un nod Destinatie si o lista de perechi de forma Path = [List,Formula], si verifica daca lista contine un path valid,
%	adica daca primul nod din lista e destinatie,iar formula asociata e true.

find_path_to_destination(D,[],[]).
find_path_to_destination(D,[Path|Paths],[N|H]):-[[N|H],F]=Path,N==D,F==true,!.
find_path_to_destination(D,[Path|Paths],R):-find_path_to_destination(D,Paths,R),!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat ce simuleaza un bfs uzual.Primeste ca argumente un nod Destinatie,un graf,o lista de Path = [List,Formula] si returneaza in Path
%	primul path de la sursa la destinatie (In caz contrar returneaza []).Ideea de baza e sa scoatem mereu de la inceputul listei initiale primul
%	Path , ii generam toate path-urile adiacente valide (folosind predicatul adauga_vecini_la_pathuri),verificam daca am gasit un Path valid catre
%	Destination	dintre cele generate,caz in care bfs-ul se opreste.Altfel,adaugam aceasta lista nou creata la sfarsitul listei initiale din care
%	am scos acum primul Path (exact ca o coada) si reapelam bfs pentru aceste argumente.Acest bfs se va opri fie cand va gasi un Path,fie cand va
% 	analiza toate caile posibile,iar Q va deveni vida si va intra pe primul caz.

bfs(D,G,[],P):- P = [].
bfs(D,G,[P|Q],Path):-adauga_vecini_la_pathuri(D,[P],G,Q_noua),find_path_to_destination(D,Q_noua,P_aux),P_aux\=[],Path=P_aux,true,!.
bfs(D,G,[P|Q],Path):-adauga_vecini_la_pathuri(D,[P],G,Q_noua),find_path_to_destination(D,Q_noua,P_aux),P_aux==[],append(Q,Q_noua,Q_final),bfs(D,G,Q_final,Path),!.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Predicat care primeste un nod Source,un nod Destinatie,un graf si o formula initiala si apleaza functia bfs astfel:verifica mai intai daca
%	formula initiala aplicata pe nodul sursa e valida,caz in care apeleaza bfs,altfel se opreste si returneaza false.Dupa generarea bfs-ului
%	daca nu gaseste Path,adica obtine [] va intoarce false,altfel va apela functia reverse pe Path pentru a obtine drumul minim de la S la D 
%	respectand formula.

getPath(From,To,G,F,false):-schimba_formula(To,G,From,F,F1),F1 \= false,bfs(To,G,[[[From],F1]],P),P==[],!.
getPath(From,To,G,F,false):-schimba_formula(To,G,From,F,F1),F1 == false,!.
getPath(From,To,G,F,Path):-schimba_formula(To,G,From,F,F1),bfs(To,G,[[[From],F1]],P),P\=[],reverse(P,Path),!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%